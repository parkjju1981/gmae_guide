# 출처 목록 (sources.md)

접속일: 2026-11-23 (Claude in Chrome, 원문 HTML 직접 파싱 — 브라우저 자동번역 미사용)

번호 | 사이트 | 제목 | URL | 언어 | 신뢰도 | 다룬 체크리스트 항목 | 저장 파일
---|---|---|---|---|---|---|---
S1 | 나무위키 | 파이어 엠블렘 Engage/등장인물 | https://namu.wiki/w/파이어%20엠블렘%20Engage/등장인물 | 한국어 | 상(한글명) | 캐릭터 한글명, 문장사 한글명·칭호, 세력 | src/namu_등장인물.txt
S2 | 나무위키 | 파이어 엠블렘 Engage/클래스 | https://namu.wiki/w/파이어%20엠블렘%20Engage/클래스 | 한국어 | 상(한글명)/중(평가) | 클래스 한글명, 클래스 평가, DLC 클래스 | src/namu_클래스.txt
S3 | 나무위키 | 파이어 엠블렘 Engage (본문) | https://namu.wiki/w/파이어%20엠블렘%20Engage | 한국어 | 중 | 시스템, 팁, 익스팬션 패스, 업데이트, 판매량 | src/namu_본문_시스템팁DLC.txt
S4 | 나무위키 | 파이어 엠블렘 Engage/스킬 | https://namu.wiki/w/파이어%20엠블렘%20Engage/스킬 | 한국어 | 상(한글명) | 스킬 한-영 대응 | src/namu_스킬.txt
S5 | 나무위키 | 일(파이어 엠블렘 시리즈) | https://namu.wiki/w/일(파이어%20엠블렘%20시리즈) | 한국어 | 중 | DLC 이계편 일/라팔 | src/namu_일_라팔.txt
S6 | Serenes Forest | Recruitment | https://serenesforest.net/engage/characters/recruitment/ | 영어 | 상 | 캐릭터 합류 챕터·조건 | src/sf_recruitment.txt
S7 | Serenes Forest | Growth Rates | https://serenesforest.net/engage/characters/growth-rates/ | 영어 | 상 | 성장률 41명 | src/sf_growth_rates.txt
S8 | Serenes Forest | Personal Skills | https://serenesforest.net/engage/characters/personal-skills/ | 영어 | 상 | 개인 스킬 | src/sf_personal_skills.txt
S9 | Serenes Forest | Paralogues / Emblems How to Obtain | https://serenesforest.net/engage/miscellaneous/paralogues/ ; https://serenesforest.net/engage/emblems/how-to-obtain/ | 영어 | 상 | 외전 해금, 반지 입수·상실·복귀 | src/sf_paralogues_emblems_obtain.txt
S10 | Serenes Forest | Emblems 개별 페이지(20종) | https://serenesforest.net/engage/emblems/<name>/ | 영어 | 상 | 문장사 효과(엔게이지 스킬/기술/무기/계승 스킬) | src/sf_emblems_1~3.txt, src/sf_emblems_4_dlc.txt
S11 | Serenes Forest | Classes Other Data / Learnable Skills | https://serenesforest.net/engage/classes/other-data/ ; https://serenesforest.net/engage/classes/learnable-skills/ | 영어 | 상 | 클래스 타입, 클래스 스킬, 루나틱 전용 적 스킬 | src/sf_classes_skills.txt
S12 | Fandom Fire Emblem Wiki | 본편 챕터 페이지(서장~26장) | https://fireemblem.fandom.com/wiki/<chapter> | 영어 | 중상 | 챕터 목표·전략·합류·아이템·보스 | src/fandom_chapters_P-04.txt, 05-11, 12-19, 20-26
S13 | Fandom Fire Emblem Wiki | 외전 페이지(1~15) | https://fireemblem.fandom.com/wiki/<paralogue> | 영어 | 중상 | 외전 내용·보상 | src/fandom_paralogues_1-8.txt, 9-15
S14 | Fandom Fire Emblem Wiki | Divine Paralogues (DLC 신장 외전 6종) | https://fireemblem.fandom.com/wiki/<page> | 영어 | 중상 | DLC 문장사 외전 | src/fandom_divine_paralogues.txt
S15 | Fandom Fire Emblem Wiki | Fell Xenologue (DLC 이계편) | https://fireemblem.fandom.com/wiki/Fell_Xenologue | 영어 | 중상 | 이계편 6챕터 | src/fandom_fell_xenologue.txt
S16 | Fandom Fire Emblem Wiki | Somniel / Draconic Time Crystal / Master Seal / Second Seal | https://fireemblem.fandom.com/wiki/Somniel | 영어 | 중상 | 소므니엘, 되감기, 전직 아이템 | src/fandom_somniel_crystal_seals.txt
S17 | Prima Games | Best Class for Each Character in Fire Emblem Engage | https://primagames.com/tips/best-class-for-each-character-in-fire-emblem-engage | 영어 | 중 | 추천 클래스 | src/prima_best_class.txt
S18 | Game8 | Character Tier List (Updated w/ DLC) | https://game8.co/games/Fire-Emblem-Engage/archives/402818 | 영어 | 중 | 캐릭터 평가·추천 클래스 | src/game8_tier_list.txt
S19 | Fandom Fire Emblem Wiki | 이미지 파일(초상·아트·표지·클래스) | https://fireemblem.fandom.com/wiki/File:<name> | - | 상 | 이미지 전부 (img/manifest.md 참고) | img/
S20 | Fire Emblem Wiki | List of classes in Fire Emblem Engage | https://fireemblemwiki.org/wiki/List_of_classes_in_Fire_Emblem_Engage | 영어(브라우저 자동번역 섞여 받음, 숫자만 사용) | 상 | 클래스 이동력·기본치·성장 보정·상한·무기 랭크·클래스 스킬 | src/fewiki_class_list.txt
S21 | Serenes Forest | Items | https://serenesforest.net/engage/weapons-items/items/ | 영어 | 상 | 능력치 상승 아이템, 부츠, 강화약, 전직 아이템 | src/sf_items.txt
S22 | Fire Emblem Wiki | Attack speed | https://fireemblemwiki.org/wiki/Attack_speed | 영어 | 상 | 무게·체격·속도 공식, 추격 기준, 회피 공식 | src/fewiki_attack_speed.txt
S23 | Fire Emblem Wiki | Somniel | https://fireemblemwiki.org/wiki/Somniel | 영어(일부 자동번역) | 상 | 투기장 규칙, 시설 해금 순서, 고대의 우물 | src/fewiki_somniel.txt
S24 | Serenes Forest | Base Stats | https://serenesforest.net/engage/characters/base-stats/ | 영어(자동번역, 숫자만 사용) | 상 | 캐릭터 초기 레벨·클래스·스탯(장 포함) | src/sf_base_stats.txt
S25 | Fire Emblem Wiki | Emblem Rings | https://fireemblemwiki.org/wiki/Emblem_Rings | 영어(자동번역 섞임) | 상 | 인게이지 지속 턴, 게이지, 인연 레벨, 반지·팔찌 영문명, 인연반지 | src/fewiki_emblem_rings.txt
S26 | 나무위키 | 뤼에르 | https://namu.wiki/w/뤼에르 | 한국어 | 상(한글명)/중 | 문장사 뤼에르 칭호, 인게이지+, 22장 기믹, 지원 목록 한국어명 | src/namu_뤼에르.txt
S27 | 나무위키 | DLC 문장사 개별 문서 7개 + 마르스(Engage) | https://namu.wiki/w/치키(파이어 엠블렘 Engage) 등 | 한국어 | 상(한글명) | 팔찌 7종 한국어명, 마르스 세계 인연반지 한국어명, 치키 스킬 | src/namu_dlc_팔찌.txt
S28 | 나무위키 | 세아다스(파이어 엠블렘 시리즈) | https://namu.wiki/w/세아다스(파이어 엠블렘 시리즈) | 한국어 | 중 | 세아다스 합류·패배 조건 | src/namu_dlc_팔찌.txt (세아다스 절)
S29 | Fire Emblem Wiki | Turn rewind | https://fireemblemwiki.org/wiki/Turn_rewind | 영어 | 상 | 되감기 횟수 | src/namu_dlc_팔찌.txt (되감기 절)

// 사용법: node render.js <guide.html 절대경로> <출력.pdf> "<푸터 제목>"
const {chromium}=require('playwright');
const [,,src,out,title='게임 공략집']=process.argv;
(async()=>{const b=await chromium.launch();const p=await b.newPage();
await p.goto('file://'+src,{waitUntil:'networkidle'});
await p.pdf({path:out,format:'A4',printBackground:true,displayHeaderFooter:true,
headerTemplate:'<div></div>',
footerTemplate:`<div style="font-size:8px;width:100%;text-align:center;color:#888;font-family:Noto Sans CJK KR">${title} · <span class="pageNumber"></span> / <span class="totalPages"></span></div>`,
margin:{top:'16mm',bottom:'16mm',left:'14mm',right:'14mm'}});
await b.close();})();

# -*- coding: utf-8 -*-
# 사용법: GUIDE_ROOT=/mnt/project-files/<slug> python3 build.py
# gen/ 폴더의 s1.py~s5.py 가 각각 html 문자열을 돌려주는 render() 함수를 가진다고 가정
import os, sys, importlib
from base import *
TITLE=os.environ.get('GUIDE_TITLE','게임 공략집')
mods=[m[:-3] for m in sorted(os.listdir(os.path.dirname(os.path.abspath(__file__)))) if m.startswith('s') and m.endswith('.py')]
body=''.join(importlib.import_module(m).render() for m in mods)
html=f'<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>{TITLE}</title><style>{CSS}</style></head><body>{body}</body></html>'
open(ROOT+'guide.html','w').write(html)
print(ROOT+'guide.html', len(html))

# -*- coding: utf-8 -*-
import os, sys
# 작업 폴더: 환경변수 GUIDE_ROOT 또는 이 파일의 상위 폴더
ROOT=os.environ.get('GUIDE_ROOT', os.path.dirname(os.path.dirname(os.path.abspath(__file__))))+'/'
IMG='img/'
def P(name): return IMG+'p_'+name+'.png'
def C(name): return IMG+'c_'+name.replace(' ','')+'.png'
def K(name): return IMG+'k_'+name+'.png'
def exists(path): return os.path.exists(ROOT+path)

CSS = r"""
@page { size: A4; margin: 16mm 14mm 16mm 14mm; }
:root{ --red:#8c1d2c; --red2:#b8323f; --gold:#b8892d; --ink:#1f1a17; --muted:#6b625b; --paper:#fffdf8; --line:#e4d9c8; --soft:#f7efe2; --blue:#2c4a7a; --green:#2f6b4a;}
*{box-sizing:border-box}
html,body{margin:0;padding:0}
body{font-family:'Noto Sans CJK KR','Noto Sans KR',sans-serif;font-size:9.6pt;line-height:1.62;color:var(--ink);background:#fff;word-break:keep-all;overflow-wrap:break-word}
h1,h2,h3,h4{font-family:'Noto Serif CJK KR','Noto Sans CJK KR',serif;font-weight:700;line-height:1.3;break-after:avoid}
h1.part{font-size:24pt;color:#fff;background:linear-gradient(120deg,var(--red),#5a0f1a);padding:18px 22px 16px;margin:0 0 14px;border-radius:6px;break-before:page;position:relative}
h1.part small{display:block;font-family:'Noto Sans CJK KR';font-weight:400;font-size:10pt;opacity:.85;margin-top:4px;letter-spacing:.02em}
h1.part .no{font-size:11pt;letter-spacing:.2em;display:block;color:#f3d48c;margin-bottom:2px}
h2{font-size:15pt;color:var(--red);border-bottom:2px solid var(--gold);padding-bottom:4px;margin:22px 0 10px}
h3{font-size:12pt;color:var(--blue);margin:16px 0 6px;padding-left:8px;border-left:4px solid var(--blue)}
h4{font-size:10.5pt;color:var(--ink);margin:12px 0 4px}
p{margin:4px 0 8px}
ul,ol{margin:4px 0 8px;padding-left:20px}
li{margin:2px 0}
table{width:100%;border-collapse:collapse;margin:6px 0 12px;font-size:8.8pt;break-inside:auto}
th{background:var(--red);color:#fff;font-weight:700;padding:5px 6px;text-align:left;border:1px solid #6d1622}
td{padding:4px 6px;border:1px solid var(--line);vertical-align:top}
tr:nth-child(even) td{background:#fbf6ee}
tr{break-inside:avoid}
.box{border-radius:6px;padding:9px 12px;margin:8px 0 12px;break-inside:avoid;border:1px solid}
.tip{background:#eef5ef;border-color:#9cc3a8}
.tip::before{content:"TIP";font-weight:700;color:var(--green);margin-right:6px}
.warn{background:#fdf0ee;border-color:#e2a69e}
.warn::before{content:"주의";font-weight:700;color:var(--red2);margin-right:6px}
.note{background:#f1f4fa;border-color:#a9b9d6}
.note::before{content:"참고";font-weight:700;color:var(--blue);margin-right:6px}
.spoil{background:#2b2230;color:#f4ecf7;border-color:#2b2230}
.spoil::before{content:"스포일러";font-weight:700;color:#f3d48c;margin-right:6px}
.key{background:var(--soft);border-color:var(--gold)}
.tag{display:inline-block;font-size:7.8pt;padding:0 6px;border-radius:9px;background:#efe5d3;color:#5a4a33;margin:0 2px 1px 0;line-height:1.6}
.tag.r{background:#f6dcdc;color:#7d1b25}.tag.b{background:#dde6f4;color:#24406b}.tag.g{background:#dcefe2;color:#235a3a}.tag.y{background:#f7ebc8;color:#6b5112}
.grid{display:grid;gap:8px}
.g2{grid-template-columns:1fr 1fr}.g3{grid-template-columns:repeat(3,1fr)}.g4{grid-template-columns:repeat(4,1fr)}.g5{grid-template-columns:repeat(5,1fr)}.g6{grid-template-columns:repeat(6,1fr)}.g8{grid-template-columns:repeat(8,1fr)}
.card{border:1px solid var(--line);border-radius:6px;padding:8px;background:#fff;break-inside:avoid}
.lord{display:flex;gap:10px;border:1px solid var(--line);border-radius:8px;padding:10px;margin:8px 0;break-inside:avoid;background:linear-gradient(180deg,#fff,#fbf7f0)}
.lord img.por{width:118px;height:150px;object-fit:contain;object-position:top;flex:none;background:#fff;border-radius:4px}
.lord .body{flex:1}
.lord h4{margin:0 0 4px;font-size:12pt;color:var(--red)}
.crest{width:28px;height:28px;object-fit:contain;vertical-align:middle;margin-right:4px}
.pc{text-align:center;font-size:8pt;break-inside:avoid}
.pc img{width:100%;height:92px;object-fit:contain;object-position:top;background:#fff}
.pc b{display:block;font-size:8.6pt}
.unit{display:flex;gap:8px;border:1px solid var(--line);border-radius:6px;padding:6px;break-inside:avoid;background:#fff}
.unit img{width:58px;height:74px;object-fit:contain;object-position:top;flex:none}
.unit .u{flex:1;font-size:8.4pt;line-height:1.5}
.unit .u b.n{font-size:9.6pt;color:var(--red)}
.cls{text-align:center;font-size:7.6pt;line-height:1.25}
.cls img{width:44px;height:44px;object-fit:contain;display:block;margin:0 auto 2px}
.chap{border:1px solid var(--line);border-radius:6px;margin:10px 0;break-inside:auto;background:#fff}
.chap .ch{background:linear-gradient(90deg,#3a2a1e,#6b4b2a);color:#fff;padding:6px 10px;border-radius:6px 6px 0 0;font-weight:700;font-size:10.5pt;break-after:avoid}
.chap .ch span{font-weight:400;font-size:8.6pt;opacity:.85;margin-left:8px}
.chap .cb{padding:7px 10px}
.chap .lbl{display:inline-block;min-width:58px;font-weight:700;color:var(--red);}
.flow{display:flex;gap:6px;align-items:stretch;margin:8px 0 12px}
.flow .st{flex:1;border-radius:6px;padding:8px;color:#fff;font-size:8.6pt;line-height:1.45}
.flow .ar{align-self:center;color:var(--gold);font-size:16pt}
.toc{columns:2;column-gap:24px;font-size:9.6pt}
.toc div{break-inside:avoid;margin-bottom:6px}
.toc b{color:var(--red)}
.cover{height:262mm;display:flex;flex-direction:column;justify-content:space-between;break-after:page}
.cover img.hero{width:100%;border-radius:8px}
.cover h1{font-size:30pt;color:var(--red);margin:14px 0 4px;text-align:center}
.cover .sub{text-align:center;font-size:12pt;color:var(--muted)}
.cover .meta{border-top:2px solid var(--gold);padding-top:10px;font-size:9pt;color:var(--muted);text-align:center}
.small{font-size:8.2pt;color:var(--muted)}
.cols2{columns:2;column-gap:16px}
.cols2 > *{break-inside:avoid}
.center{text-align:center}
.pb{break-before:page}
.kv td:first-child{width:24%;font-weight:700;background:#faf3e6}
.star{color:var(--gold)}
"""
def h(tag,txt,cls=''):
    return f'<{tag} class="{cls}">{txt}</{tag}>' if cls else f'<{tag}>{txt}</{tag}>'
def table(head,rows,cls='',widths=None):
    s=f'<table class="{cls}">'
    if widths: s+='<colgroup>'+''.join(f'<col style="width:{w}">' for w in widths)+'</colgroup>'
    if head: s+='<tr>'+''.join(f'<th>{x}</th>' for x in head)+'</tr>'
    for r in rows: s+='<tr>'+''.join(f'<td>{x}</td>' for x in r)+'</tr>'
    return s+'</table>'
def box(kind,html): return f'<div class="box {kind}">{html}</div>'
def ul(items): return '<ul>'+''.join(f'<li>{i}</li>' for i in items)+'</ul>'
def part(no,title,sub=''): return f'<h1 class="part"><span class="no">PART {no}</span>{title}<small>{sub}</small></h1>'
def tag(t,c=''): return f'<span class="tag {c}">{t}</span>'

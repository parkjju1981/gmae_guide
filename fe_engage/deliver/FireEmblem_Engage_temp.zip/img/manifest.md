# 이미지 목록 (img/manifest.md)

수집 방법: Fandom(fireemblem.fandom.com) 원본 이미지를 브라우저 그리드에 띄워 스크린샷 → Pillow로 크롭(흰 배경 자동 트림). 원본보다 해상도 낮음(초상 세로 약 310~360px, JPEG 압축 흔적 있음). 출처 URL은 Fandom 파일 페이지.

파일명 | 무엇인지 | 크기 | 출처 URL
---|---|---|---
p_반드레.png | 아군 캐릭터 초상 | 353x360 | https://fireemblem.fandom.com/wiki/File:VanderFE17Portrait.png
e_마르스.png | 문장사 초상 [공식 아트워크(전신), 다른 초상과 스타일 다름] | 359x343 | https://fireemblem.fandom.com/wiki/File:MarthFE17Artwork.png
p_마델린.png | 아군 캐릭터 초상 | 328x340 | https://fireemblem.fandom.com/wiki/File:MadelineFE17Portrait.png
p_프랑.png | 아군 캐릭터 초상 | 303x360 | https://fireemblem.fandom.com/wiki/File:FrammeFE17Portrait.png
p_젤코바.png | 아군 캐릭터 초상 | 240x360 | https://fireemblem.fandom.com/wiki/File:ZelkovFE17Portrait.png
p_보네.png | 아군 캐릭터 초상 | 360x360 | https://fireemblem.fandom.com/wiki/File:BunetFE17Portrait.png
p_미스티라.png | 아군 캐릭터 초상 [공식 아트워크(전신), 다른 초상과 스타일 다름] | 327x360 | https://fireemblem.fandom.com/wiki/File:TimerraFE17Artwork.png
p_알프레드.png | 아군 캐릭터 초상 [공식 아트워크(전신), 다른 초상과 스타일 다름] | 231x360 | https://fireemblem.fandom.com/wiki/File:AlfredFE17Artwork.png
p_장.png | 아군 캐릭터 초상 | 194x360 | https://fireemblem.fandom.com/wiki/File:JeanFE17Portrait.png
p_골드마리.png | 아군 캐릭터 초상 | 317x360 | https://fireemblem.fandom.com/wiki/File:GoldmaryFE17Portrait.png
p_린덴.png | 아군 캐릭터 초상 | 238x335 | https://fireemblem.fandom.com/wiki/File:LindonFE17Portrait.png
p_자피아.png | 아군 캐릭터 초상 | 344x344 | https://fireemblem.fandom.com/wiki/File:SaphirFE17Portrait.png
p_그레고리.png | 아군 캐릭터 초상 | 344x342 | https://fireemblem.fandom.com/wiki/File:GregoryFE17Portrait.png
p_세아다스.png | 아군 캐릭터 초상 | 375x360 | https://fireemblem.fandom.com/wiki/File:SeadallFE17Portrait.png
p_루이.png | 아군 캐릭터 초상 | 350x360 | https://fireemblem.fandom.com/wiki/File:LouisFE17Portrait.png
p_앰버.png | 아군 캐릭터 초상 | 303x360 | https://fireemblem.fandom.com/wiki/File:AmberFE17Portrait.png
p_아이비.png | 아군 캐릭터 초상 [공식 아트워크(전신), 다른 초상과 스타일 다름] | 343x360 | https://fireemblem.fandom.com/wiki/File:IvyFE17Artwork.png
p_디아만드.png | 아군 캐릭터 초상 [공식 아트워크(전신), 다른 초상과 스타일 다름] | 383x360 | https://fireemblem.fandom.com/wiki/File:DiamantFE17Artwork.png
p_클랜.png | 아군 캐릭터 초상 | 246x360 | https://fireemblem.fandom.com/wiki/File:ClanneFE17Portrait.png
p_부셰론.png | 아군 캐릭터 초상 | 343x353 | https://fireemblem.fandom.com/wiki/File:BoucheronFE17Portrait.png
p_에티에.png | 아군 캐릭터 초상 | 241x351 | https://fireemblem.fandom.com/wiki/File:EtieFE17Portrait.png
p_셀린.png | 아군 캐릭터 초상 | 344x360 | https://fireemblem.fandom.com/wiki/File:CélineFE17Portrait.png
p_클로에.png | 아군 캐릭터 초상 | 332x358 | https://fireemblem.fandom.com/wiki/File:ChloéFE17Portrait.png
p_유나카.png | 아군 캐릭터 초상 | 320x333 | https://fireemblem.fandom.com/wiki/File:YunakaFE17Portrait.png
p_스타루크.png | 아군 캐릭터 초상 | 255x360 | https://fireemblem.fandom.com/wiki/File:AlcrystFE17Portrait.png
p_시트리니카.png | 아군 캐릭터 초상 | 348x360 | https://fireemblem.fandom.com/wiki/File:CitrinneFE17Portrait.png
p_라피스.png | 아군 캐릭터 초상 | 227x360 | https://fireemblem.fandom.com/wiki/File:LapisFE17Portrait.png
p_제이데.png | 아군 캐릭터 초상 | 351x360 | https://fireemblem.fandom.com/wiki/File:JadeFE17Portrait.png
p_카게츠.png | 아군 캐릭터 초상 | 298x360 | https://fireemblem.fandom.com/wiki/File:KagetsuFE17Portrait.png
p_포가토.png | 아군 캐릭터 초상 | 373x345 | https://fireemblem.fandom.com/wiki/File:FogadoFE17Portrait.png
p_판도로.png | 아군 캐릭터 초상 | 357x359 | https://fireemblem.fandom.com/wiki/File:PandreoFE17Portrait.png
p_메린.png | 아군 캐릭터 초상 | 334x360 | https://fireemblem.fandom.com/wiki/File:MerrinFE17Portrait.png
p_파네토네.png | 아군 캐릭터 초상 | 314x360 | https://fireemblem.fandom.com/wiki/File:PanetteFE17Portrait.png
p_오르텐시아.png | 아군 캐릭터 초상 | 397x360 | https://fireemblem.fandom.com/wiki/File:HortensiaFE17Portrait.png
p_로사도.png | 아군 캐릭터 초상 | 376x360 | https://fireemblem.fandom.com/wiki/File:RosadoFE17Portrait.png
p_모브.png | 아군 캐릭터 초상 | 411x360 | https://fireemblem.fandom.com/wiki/File:MauvierFE17Portrait.png
p_베일.png | 아군 캐릭터 초상 | 338x352 | https://fireemblem.fandom.com/wiki/File:VeyleFE17Portrait.png
p_안나.png | 아군 캐릭터 초상 | 282x360 | https://fireemblem.fandom.com/wiki/File:AnnaFE17Portrait.png
p_엘.png | 아군 캐릭터 초상 | 256x328 | https://fireemblem.fandom.com/wiki/File:NelFE17Portrait.png
p_일.png | 아군 캐릭터 초상 | 302x327 | https://fireemblem.fandom.com/wiki/File:NilFE17Portrait.png
p_셀레스티아.png | 아군 캐릭터 초상 | 337x360 | https://fireemblem.fandom.com/wiki/File:ZelestiaFE17Portrait.png
e_세리카.png | 문장사 초상 | 249x347 | https://fireemblem.fandom.com/wiki/File:CelicaFE17Portrait.png
e_시구르드.png | 문장사 초상 | 311x355 | https://fireemblem.fandom.com/wiki/File:SigurdFE17Portrait.png
e_리프.png | 문장사 초상 | 356x360 | https://fireemblem.fandom.com/wiki/File:LeifFE17Portrait.png
e_로이.png | 문장사 초상 | 344x360 | https://fireemblem.fandom.com/wiki/File:RoyFE17Portrait.png
e_린.png | 문장사 초상 | 244x360 | https://fireemblem.fandom.com/wiki/File:LynFE17Portrait.png
e_에이리카.png | 문장사 초상 | 354x343 | https://fireemblem.fandom.com/wiki/File:EirikaFE17Portrait.png
e_에브라임.png | 문장사 초상 | 473x336 | https://fireemblem.fandom.com/wiki/File:EphraimFE17Portrait.png
e_아이크.png | 문장사 초상 | 310x336 | https://fireemblem.fandom.com/wiki/File:IkeFE17Portrait.png
e_미카야.png | 문장사 초상 | 309x336 | https://fireemblem.fandom.com/wiki/File:MicaiahFE17Portrait.png
e_루키나.png | 문장사 초상 | 270x336 | https://fireemblem.fandom.com/wiki/File:LucinaFE17Portrait.png
e_에델가르트.png | 문장사 초상 | 320x335 | https://fireemblem.fandom.com/wiki/File:EdelgardFE17Portrait.png
e_디미트리.png | 문장사 초상 | 317x335 | https://fireemblem.fandom.com/wiki/File:DimitriFE17Portrait.png
e_클로드.png | 문장사 초상 | 344x316 | https://fireemblem.fandom.com/wiki/File:ClaudeFE17Portrait.png
e_치키.png | 문장사 초상 | 274x316 | https://fireemblem.fandom.com/wiki/File:TikiFE17Portrait.png
e_헥터.png | 문장사 초상 | 313x324 | https://fireemblem.fandom.com/wiki/File:HectorFE17Portrait.png
e_세네리오.png | 문장사 초상 | 321x315 | https://fireemblem.fandom.com/wiki/File:SorenFE17Portrait.png
e_카밀라.png | 문장사 초상 | 295x322 | https://fireemblem.fandom.com/wiki/File:CamillaFE17Portrait.png
e_크롬.png | 문장사 초상 | 329x336 | https://fireemblem.fandom.com/wiki/File:ChromFE17Portrait.png
e_베로니카.png | 문장사 초상 | 270x317 | https://fireemblem.fandom.com/wiki/File:VeronicaFE17Portrait.png
e_러플레.png | 문장사 초상 | 354x336 | https://fireemblem.fandom.com/wiki/File:RobinFE17Portrait.png
p_뤼에르.png | 아군 캐릭터 초상 (여성 주인공) | 298x336 | https://fireemblem.fandom.com/wiki/File:FAlearFE17Portrait.png
p_뤼에르_남.png | 아군 캐릭터 초상 (남성 주인공) | 271x336 | https://fireemblem.fandom.com/wiki/File:MAlearFE17Portrait.png
e_뤼에르.png | 문장사 초상 (문장사 형태 뤼에르, 여성) | 304x335 | https://fireemblem.fandom.com/wiki/File:FAlearEmblemFE17Portrait.png
e_카무이.png | 문장사 초상 (여성 카무이) | 310x336 | https://fireemblem.fandom.com/wiki/File:FCorrinFE17Portrait.png
e_벨레트.png | 문장사 초상 (남성 벨레트) | 276x336 | https://fireemblem.fandom.com/wiki/File:MBylethFE17Portrait.png
p_라팔.png | 아군 캐릭터 초상 — 일(Nil)과 동일 인물·동일 이미지(본편 합류명 라팔) | 282x306 | https://fireemblem.fandom.com/wiki/File:NilFE17Portrait.png
cover_package.png | 패키지 아트 (유럽판 PEGI 12 표기 포함) | 483x784 | https://fireemblem.fandom.com/wiki/File:Fire_Emblem_Engage_Box_Art.png
cover_wide.png | 와이드 키아트 (로고 포함) | 1393x784 | https://fireemblem.fandom.com/wiki/File:Fire_Emblem_Engage_Key_Art.png
c_베르세르크.png | 클래스 모습 (남성 뤼에르가 해당 클래스로 전직한 인게임 스크린샷; 아이콘 대체) | 757x387 | https://fireemblem.fandom.com/wiki/File:Berserker-Male-Alear.JPG
c_제너럴.png | 클래스 모습 (남성 뤼에르가 해당 클래스로 전직한 인게임 스크린샷; 아이콘 대체) | 758x387 | https://fireemblem.fandom.com/wiki/File:General-Male-Alear.JPG
c_할버디어.png | 클래스 모습 (남성 뤼에르가 해당 클래스로 전직한 인게임 스크린샷; 아이콘 대체) | 757x387 | https://fireemblem.fandom.com/wiki/File:Halberdier-Male-Alear.JPG
c_브레이브히어로.png | 클래스 모습 (남성 뤼에르가 해당 클래스로 전직한 인게임 스크린샷; 아이콘 대체) | 758x387 | https://fireemblem.fandom.com/wiki/File:Hero-Male-Alear.JPG
c_팔라딘.png | 클래스 모습 (남성 뤼에르가 해당 클래스로 전직한 인게임 스크린샷; 아이콘 대체) | 757x387 | https://fireemblem.fandom.com/wiki/File:Paladin-Male-Alear.JPG
c_세이지.png | 클래스 모습 (남성 뤼에르가 해당 클래스로 전직한 인게임 스크린샷; 아이콘 대체) | 758x387 | https://fireemblem.fandom.com/wiki/File:Sage-Male-Alear.JPG
c_스나이퍼.png | 클래스 모습 (남성 뤼에르가 해당 클래스로 전직한 인게임 스크린샷; 아이콘 대체) | 757x387 | https://fireemblem.fandom.com/wiki/File:Sniper-Male-Alear.JPG
c_소드마스터.png | 클래스 모습 (남성 뤼에르가 해당 클래스로 전직한 인게임 스크린샷; 아이콘 대체) | 758x387 | https://fireemblem.fandom.com/wiki/File:Swordmaster-Male-Alear.JPG
c_시프.png | 클래스 모습 (남성 뤼에르가 해당 클래스로 전직한 인게임 스크린샷; 아이콘 대체) | 757x387 | https://fireemblem.fandom.com/wiki/File:Thief-Male-Alear.JPG
c_워리어.png | 클래스 모습 (남성 뤼에르가 해당 클래스로 전직한 인게임 스크린샷; 아이콘 대체) | 758x387 | https://fireemblem.fandom.com/wiki/File:Warrior-Male-Alear.JPG

미확보: 클래스 아이콘(게임 UI 아이콘) — Fandom/SF에서 찾지 못함. 위 c_ 이미지 10장으로 대체. 4왕국 문장·월드맵·챕터 맵 이미지 미수집.
